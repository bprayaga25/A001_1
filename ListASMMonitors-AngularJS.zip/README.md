# Getting started

## How to Build

The generated SDK requires AngularJS framework to work. If you do not already have angular downloaded, please go ahead and do it from [here](https://angularjs.org/).
If any of your models have `Date` or `Datetime` type fields or your endpoints have `Date`/`Datetime` type response, you will need to download and link [angular-moment](https://cdnjs.cloudflare.com/ajax/libs/angular-moment/1.0.1/angular-moment.min.js) and [moment.js](https://cdnjs.cloudflare.com/ajax/libs/moment.js/2.17.1/moment.min.js) with your project.

## How to Use

The following section describes how to use the generated SDK in an existing/new project.

### 1. Configure Angular and Generated SDK
Perform the following steps to configure angular and the SDK:
+ Make a `scripts` folder inside the root folder of the project. If you already have a `scripts` folder, skip to the next step.
+ Move the `angular.min.js` file inside the scripts folder. 
+ Move the `listasmmonitorslib` folder inside the scripts folder.
+ If any of the Custom Types in your API have `Date`/`Datetime` type fields or any endpoint has `Date`/`Datetime` response, you will need to download angular-moment and moment.js. Move these 2 files into the `scripts` folder as well.

![folder-structure-image](https://apidocs.io/illustration/angularjs?step=folderStructure&workspaceFolder=ListASMMonitors-Angular&projectName=ListASMMonitorsLib)

### 2. Open Project Folder
Open an IDE/Text Editor for JavaScript like Sublime Text. The basic workflow presented here is also applicable if you prefer using a different editor or IDE.  
Click on `File` and select `Open Folder`

Select the folder of your SDK and click on `Select Folder` to open it up in Sublime Text. The folder will become visible in the bar on the left.

![open-folder-image](https://apidocs.io/illustration/angularjs?step=openFolder&workspaceFolder=ListASMMonitors-Angular)

### 3. Create an Angular Application
Since Angular JS is used for client-side web development, in order to use the generated library, you will have to develop an application first.
If you already have an angular application, [skip to Step 6](#6-include-sdk-references-in-html-file). Otherwise, follow these steps to create one:

+ In the IDE, click on `File` and choose `New File` to create a new file.
+ Add the following starting code in the file:
```js
    var app = angular.module('myApp', []);
    app.controller('testController', function($scope) 
    {

    });
```
+ Save it with the name `app.js` in the `scripts` folder.


### 4. Create HTML File
Skip to the next step if you are working with an existing project and already have an html file. Otherwise follow the steps to create one:
+ Inside the IDE, right click on the project folder name and select the `New File` option to create a new test file.
+ Save it with an appropriate name such as `index.html` in the root of your project folder.
`index.html` should look like this:
```html
	<!DOCTYPE html>
	<html>
	<head>
		<title>Angular Project</title>
		<script></script>
	</head>

	<body>
	</body>

	</html>
```

![initial-html-code-image](https://apidocs.io/illustration/angularjs?step=initialCode&workspaceFolder=ListASMMonitors-Angular)

### 5. Including links to Angular in HTML file
Your HTML file needs to have a link to `angular.min.js` file to use Angular-JS. Add the link using `script` tags inside the `head` section of `index.html` like:
```html
	<script src="scripts/angular.min.js" ></script>
```
If any of the Custom Types that you have defined have `Date`/`Datetime` type fields or any endpoint has `Date`/`Datetime` response, you will also need to link to angular-moment and moment.js like:
```html
	<script src="scripts/angular.min.js" ></script>
	<script src="scripts/moment.min.js" ></script>
	<script src="scripts/angular-moment.min.js" ></script>
```

### 6. Include SDK references in HTML file
Import the reference to the generated SDK files inside your html file like:
```html
	<head>
		...
		<!-- Helper files -->
		<script src="scripts/listasmmonitorslib/Module.js"></script>
		<script src="scripts/listasmmonitorslib/Configuration.js"></script>
		<script src="scripts/listasmmonitorslib/APIHelper.js"></script>
		<script src="scripts/listasmmonitorslib/Http/Client/HttpContext.js"></script>
		<script src="scripts/listasmmonitorslib/Http/Client/RequestClient.js"></script>
		<script src="scripts/listasmmonitorslib/Http/Request/HttpRequest.js"></script>
		<script src="scripts/listasmmonitorslib/Http/Response/HttpResponse.js"></script>

		<!-- API Controllers -->
        <script src="scripts/listasmmonitorslib/Controllers/APIController.js"></script>
        <script src="scripts/listasmmonitorslib/Controllers/ListASMMonitorsController.js"></script>
        <script src="scripts/listasmmonitorslib/Controllers/BlazeTestController.js"></script>


		<!-- Models -->
        <script src="scripts/listasmmonitorslib/Models/BaseModel.js"></script>
        <script src="scripts/listasmmonitorslib/Models/ListASMMonitors.js"></script>
        <script src="scripts/listasmmonitorslib/Models/NewValue.js"></script>

		...
	</head>
```
> The `Module.js` file should be imported before the other files. After `Module.js`, `Configuration.js` should be imported.

### 7. Including link to `app.js` in HTML file
Link your `app.js` file to your `index.html` file like:
```html
	<head>
		...
		<script src="scripts/app.js"></script>
	</head>
```
> The link to app.js needs to be included at the very end of the head tag, after the SDK references have been added

### 8. Initializing the Angular App
You need to initialize your app and the controller associated with your view inside your `index.html` file. Do so like:
+ Add ng-app directive to initialize your app inside the `body` tag.
```html
	<body ng-app="myApp">
```
+ Add ng-controller directive to initialize your controller and bind it with your view (`index.html` file).
```html
	...
	<body ng-app="myApp">
		<div ng-controller="testController">
			...
		</div>
		...
	</body>
	...
```

### 9. Consuming the SDK 
In order to use the generated SDK's modules, controllers and factories, the project needs to be added as a dependency in your angular app's module. This will be done inside the `app.js` file.
Add the dependency like this:

```js
    var app = angular.module('myApp', ['ListASMMonitorsLib']);
```
At this point, the SDK has been successfully included in your project. Further steps include using a service/factory from the generated SDK. To see working example of this, please head on [over here](#list-of-controllers) and choose any class to see its functions and example usage.  

### 10. Running The App
To run the app, simply open up the `index.html` file in a browser.

![app-running](https://apidocs.io/illustration/angularjs?step=appRunning)

## Initialization

### Authentication
In order to setup authentication and initialization of the Angular App, you need the following information.

| Parameter | Description |
|-----------|-------------|
| basicAuthUserName | The username to use with basic authentication |
| basicAuthPassword | The password to use with basic authentication |



```JavaScript
// Configuration parameters and credentials
basicAuthUserName = "basicAuthUserName"; // The username to use with basic authentication
basicAuthPassword = "basicAuthPassword"; // The password to use with basic authentication

```
The Angular App can be initialized as following:
```html
<body ng-app="myApp">
    <div ng-controller="testController">
        ...
    </div>
    ...
</body>
```
> The initialization code will be added inside the `index.html` file (which is the view of the app you have created). More detail about this can be found in the [`How to Use`](#how-to-use) section

## Class Reference

### <a name="list_of_controllers"></a>List of Controllers

* [APIController](#api_controller)
* [ListASMMonitorsController](#list_asm_monitors_controller)
* [BlazeTestController](#blaze_test_controller)

### <a name="api_controller"></a>![Class: ](https://apidocs.io/img/class.png ".APIController") APIController

#### Get singleton instance

The singleton instance of the ``` APIController ``` class can be accessed via Dependency Injection.

```js
	app.controller("testController", function($scope, APIController,ListASMMonitors,NewValue){
	});
```

#### <a name="find_info"></a>![Method: ](https://apidocs.io/img/method.png ".APIController.findInfo") findInfo

> Returns all info from the system that the user has access to


```javascript
function findInfo(tags, limit)
```
#### Parameters

| Parameter | Tags | Description |
|-----------|------|-------------|
| tags |  ``` Optional ```  ``` Collection ```  | tags to filter by |
| limit |  ``` Optional ```  | maximum number of results to return |



#### Example Usage

```javascript


	app.controller("testController", function($scope, APIController,ListASMMonitors,NewValue){
	    var tags = ["tags"];
    var limit = 108;


		var result = APIController.findInfo(tags, limit);
        //Function call returns a promise
        result.then(function(success){
			//success case
			//getting context of response
			console.log(success.getContext());
		},function(err){
			//failure case
		});

	});
```

#### Errors

| Error Code | Error Description |
|------------|-------------------|
| 0 | unexpected error |




#### <a name="add_value"></a>![Method: ](https://apidocs.io/img/method.png ".APIController.addValue") addValue

> Creates a new  in the store.  Duplicates are allowed


```javascript
function addValue(new)
```
#### Parameters

| Parameter | Tags | Description |
|-----------|------|-------------|
| new |  ``` Required ```  | Add to the store |



#### Example Usage

```javascript


	app.controller("testController", function($scope, APIController,ListASMMonitors,NewValue){
	    var new = new NewValue({"key":"value"});


		var result = APIController.addValue(new);
        //Function call returns a promise
        result.then(function(success){
			//success case
			//getting context of response
			console.log(success.getContext());
		},function(err){
			//failure case
		});

	});
```

#### Errors

| Error Code | Error Description |
|------------|-------------------|
| 0 | unexpected error |




[Back to List of Controllers](#list_of_controllers)

### <a name="list_asm_monitors_controller"></a>![Class: ](https://apidocs.io/img/class.png ".ListASMMonitorsController") ListASMMonitorsController

#### Get singleton instance

The singleton instance of the ``` ListASMMonitorsController ``` class can be accessed via Dependency Injection.

```js
	app.controller("testController", function($scope, ListASMMonitorsController,ListASMMonitors,NewValue){
	});
```

#### <a name="update_value"></a>![Method: ](https://apidocs.io/img/method.png ".ListASMMonitorsController.updateValue") updateValue

> deletes


```javascript
function updateValue(body)
```
#### Parameters

| Parameter | Tags | Description |
|-----------|------|-------------|
| body |  ``` Optional ```  | object that needs to be added to the store |



#### Example Usage

```javascript


	app.controller("testController", function($scope, ListASMMonitorsController,ListASMMonitors,NewValue){
	    var body = new ListASMMonitors|null({"key":"value"});


		var result = ListASMMonitorsController.updateValue(body);
        //Function call returns a promise
        result.then(function(success){
			//success case
			//getting context of response
			console.log(success.getContext());
		},function(err){
			//failure case
		});

	});
```

#### Errors

| Error Code | Error Description |
|------------|-------------------|
| 400 | Invalid ID supplied |
| 404 |  Not found |
| 405 | Validation exception |




[Back to List of Controllers](#list_of_controllers)

### <a name="blaze_test_controller"></a>![Class: ](https://apidocs.io/img/class.png ".BlazeTestController") BlazeTestController

#### Get singleton instance

The singleton instance of the ``` BlazeTestController ``` class can be accessed via Dependency Injection.

```js
	app.controller("testController", function($scope, BlazeTestController,ListASMMonitors,NewValue){
	});
```

#### <a name="delete_value"></a>![Method: ](https://apidocs.io/img/method.png ".BlazeTestController.deleteValue") deleteValue

> TODO: Add a method description


```javascript
function deleteValue(apiKey)
```
#### Parameters

| Parameter | Tags | Description |
|-----------|------|-------------|
| apiKey |  ``` Required ```  | TODO: Add a parameter description |



#### Example Usage

```javascript


	app.controller("testController", function($scope, BlazeTestController,ListASMMonitors,NewValue){
	    var apiKey = api_key;


		var result = BlazeTestController.deleteValue(apiKey);
        //Function call returns a promise
        result.then(function(success){
			//success case
			//getting context of response
			console.log(success.getContext());
		},function(err){
			//failure case
		});

	});
```

#### Errors

| Error Code | Error Description |
|------------|-------------------|
| 400 | Invalid  value |




[Back to List of Controllers](#list_of_controllers)



